const readlineSync = require('readline-sync'); 
const fs = require('fs').promises;
const path = require('path');

function cesarCipher(str, idx) {
    let result = '';
    let alphabet = 'abcdefghijklmnopqrstuvwxyz';
    for (let letter of str) {
        let index = alphabet.indexOf(letter.toLowerCase());
        if (index !== -1) {
            let newIndex = (index + idx) % 26;
            let newLetter = alphabet[newIndex];
            result += letter === letter.toUpperCase() ? newLetter.toUpperCase() : newLetter;
        } else {
            result += letter;
        }
    }
    return result;
}

async function registerUser() {
    let userName = readlineSync.question('Enter your username: ');
    let password = readlineSync.question('Enter your password: ');

    let passwordCifrada = cesarCipher(password, 7);

    console.log("Welcome " + userName);
    console.log("Encrypted Password: " + passwordCifrada);

    await addUser(userName, passwordCifrada);
}

async function addUser(userName, passwordCifrada) {
    const filePath = path.join(__dirname, 'users.json');
    let users = [];
    try {
        try {
            const data = await fs.readFile(filePath);
            users = JSON.parse(data);
        } catch (err) {
            if (err.code !== 'ENOENT') {
                throw err;
            }
        }

        if (users.some(user => user.userName === userName)) {
            console.log('User already exists');
            return;
        }

        users.push({ userName, passwordCifrada });
        await fs.writeFile(filePath, JSON.stringify(users));
        console.log('User added');
    } catch (err) {
        console.error('Error saving the user:', err);
    }
}

async function login() {
    let userName = readlineSync.question('Enter your username: ');
    let password = readlineSync.question('Enter your password: ');

    const filePath = path.join(__dirname, 'users.json');

    try {
        const data = await fs.readFile(filePath);
        let users = JSON.parse(data);
        for (let user of users) {
            if (userName === user.userName && cesarCipher(password, 7) === user.passwordCifrada) {
                console.log('Welcome ' + userName);
                return;
            }
        }
        console.log('Invalid username or password');
    } catch (err) {
        console.log('Error reading the file:', err);
    }
}

function mainMenu() {
    let choice = '';
    while (choice !== '3') {
        console.log('\n1. Register');
        console.log('2. Login');
        console.log('3. Exit');
        choice = readlineSync.question('Choose an option: ');

        switch (choice) {
            case '1':
                registerUser();
                break;
            case '2':
                login();
                break;
            case '3':
                console.log('Exiting...');
                break;
            default:
                console.log('Invalid option');
        }
    }
}

mainMenu();
